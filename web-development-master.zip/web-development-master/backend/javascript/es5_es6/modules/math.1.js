const add = function(a, b) {
	return a + b;
};

const substract = function(a, b) {
	return a - b;
};

const multiple = function(a, b) {
	return a * b;
};

module.exports = {
	add,
	substract,
	multiple
};
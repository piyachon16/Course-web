module.exports.add = function(a, b) {
	return a + b;
};

module.exports.substract = function(a, b) {
	return a - b;
};

module.exports.multiple = function(a, b) {
	return a * b;
};
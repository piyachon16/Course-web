const str1 = "In ES6 " + 
            "multi-line is " + 
            "okay.";
console.log("str1: " + str1);

const str2 = `In ES6 
            multi-line is 
            okay.`;
console.log(`str2: ${str2}`);

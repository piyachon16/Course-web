var profile = { firstname: "Olan", lastname: "Samritjiarapon" };
console.log(profile);
var http = require("http");


http.createServer((req, resp) => {
    // Read file demo.html
    
})
.listen(8081);

console.log("Server running at http://127.0.0.1:8081/");
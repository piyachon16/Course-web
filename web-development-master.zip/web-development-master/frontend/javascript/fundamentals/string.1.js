var txt = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
var sln = txt.length;

var str = "HELLO WORLD";
var res = str.charAt(0);

var str = "Please locate where 'locate' occurs!";
var pos = str.indexOf("locate");

var str = "Please locate where 'locate' occurs!";
var pos = str.lastIndexOf("locate");

var str = "Visit Microsoft!";
var res = str.replace("Microsoft", "OlanLab");